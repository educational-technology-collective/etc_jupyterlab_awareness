"use strict";
(self["webpackChunk_educational_technology_collective_etc_jupyterlab_awareness"] = self["webpackChunk_educational_technology_collective_etc_jupyterlab_awareness"] || []).push([["lib_index_js"],{

/***/ "./lib/handler.js":
/*!************************!*\
  !*** ./lib/handler.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "requestAPI": () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'etc-jupyterlab-awareness', // API Namespace
    endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    let data = await response.text();
    if (data.length > 0) {
        try {
            data = JSON.parse(data);
        }
        catch (error) {
            console.log('Not a JSON response body.', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message || data);
    }
    return data;
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_statedb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/statedb */ "webpack/sharing/consume/default/@jupyterlab/statedb");
/* harmony import */ var _jupyterlab_statedb__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_statedb__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");




const PLUGIN_ID = '@educational-technology-collective/etc_jupyterlab_awareness:plugin';
/**
 * Initialization data for the @educational-technology-collective/etc_jupyterlab_awareness extension.
 */
const plugin = {
    id: PLUGIN_ID,
    autoStart: true,
    requires: [_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1__.ISettingRegistry, _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker, _jupyterlab_statedb__WEBPACK_IMPORTED_MODULE_2__.IStateDB],
    activate: (app, settingRegistry, notebookTracker, stateDB) => {
        (async () => {
            var _a, _b;
            console.log('JupyterLab extension @educational-technology-collective/etc_jupyterlab_awareness is activated!');
            await app.restored;
            console.log('document.cookie1', document.cookie);
            let env = await (0,_handler__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('get_example');
            console.log('env', env);
            let hubUser = env['os.environ']['JUPYTERHUB_USER'];
            console.log('hub_user', hubUser);
            if (!((_b = (_a = document === null || document === void 0 ? void 0 : document.cookie) === null || _a === void 0 ? void 0 : _a.split('; ')) === null || _b === void 0 ? void 0 : _b.find(row => row.startsWith('hub_user=')))) {
                document.cookie = `hub_user=${hubUser}; domain=mentoracademy.org; path=/; max-age=${60 * 60 * 24 * 365};`;
            }
            console.log('document.cookie2', document.cookie);
            notebookTracker.forEach((notebookPanel) => {
                var _a, _b, _c, _d;
                console.log('forEach');
                console.log('document.cookie', document.cookie);
                let hubUser = (_c = (_b = (_a = document === null || document === void 0 ? void 0 : document.cookie) === null || _a === void 0 ? void 0 : _a.split('; ')) === null || _b === void 0 ? void 0 : _b.find(row => row.startsWith('hub_user='))) === null || _c === void 0 ? void 0 : _c.split('=')[1];
                ((_d = notebookPanel === null || notebookPanel === void 0 ? void 0 : notebookPanel.content.model) === null || _d === void 0 ? void 0 : _d.sharedModel).awareness.setLocalStateField('user', { name: hubUser });
            });
            notebookTracker.widgetAdded.connect(async (sender, notebookPanel) => {
                var _a, _b, _c, _d;
                console.log('notebookTracker.widgetAdded');
                await notebookPanel.revealed;
                await notebookPanel.sessionContext.ready;
                console.log('document.cookie', document.cookie);
                let hubUser = (_c = (_b = (_a = document === null || document === void 0 ? void 0 : document.cookie) === null || _a === void 0 ? void 0 : _a.split('; ')) === null || _b === void 0 ? void 0 : _b.find(row => row.startsWith('hub_user='))) === null || _c === void 0 ? void 0 : _c.split('=')[1];
                ((_d = notebookPanel === null || notebookPanel === void 0 ? void 0 : notebookPanel.content.model) === null || _d === void 0 ? void 0 : _d.sharedModel).awareness.setLocalStateField('user', { name: hubUser });
                console.log('hub_user', hubUser);
            });
            notebookTracker.currentChanged.connect(async (sender, notebookPanel) => {
                console.log('notebookTracker.currentChanged');
            });
            notebookTracker.widgetUpdated.connect(async (sender, notebookPanel) => {
                console.log('notebookTracker.widgetUpdated');
            });
            // requestAPI<any>('get_example')
            //   .then(data => {
            //     console.log('os.getenv()', data);
            //   })
            //   .catch(reason => {
            //     console.error(
            //       `The etc_jupyterlab_awareness server extension appears to be missing.\n${reason}`
            //     );
            //   });
            // console.log(document.cookie);
            // (notebookPanel?.content.model?.sharedModel as any).awareness.setLocalStateField('user', { name: Date.now().toString() });
            // if (settingRegistry) {
            //   settingRegistry
            //     .load(plugin.id)
            //     .then(settings => {
            //       settings.user
            //       console.log('@educational-technology-collective/etc_jupyterlab_awareness settings loaded:', settings.composite);
            //     })
            //     .catch(reason => {
            //       console.error('Failed to load settings for @educational-technology-collective/etc_jupyterlab_awareness.', reason);
            //     });
            // }
        })();
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.8a0450d1673198edcd0f.js.map